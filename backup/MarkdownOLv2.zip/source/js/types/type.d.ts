type MD = string

type DB = any

interface ImgData {
  uuid: number
  imgBase64: string 
}
