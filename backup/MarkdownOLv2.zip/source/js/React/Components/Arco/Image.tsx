import { Image } from '@arco-design/web-react';

function App() {
  return (
    <Image
      width={200}
      src='//p1-arco.byteimg.com/tos-cn-i-uwbnlip3yd/a8c8cdb109cb051163646151a4a5083b.png~tplv-uwbnlip3yd-webp.webp'
      alt='lamp'
    />
  );
}

export default App;
