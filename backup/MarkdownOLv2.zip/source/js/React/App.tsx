// import { useState } from "react";
// import "./App.less"
import Menu from "./SubComponents/SubHeader/Menu"
import Image from "./Components/Arco/Image"
import Gridv2 from "./Components/Mui/Gridv2"
import Header from "./SubComponents/Header"
// import DragBox from "./Components/myCom/DragBox"
import "@arco-design/web-react/dist/css/arco.css"
import Body from "./SubComponents/Body"
// import { Button } from "@mui/material"
function App() {
  return (
    <>
      <Header></Header>
      <Body></Body>
    </>
  )
}

export default App
