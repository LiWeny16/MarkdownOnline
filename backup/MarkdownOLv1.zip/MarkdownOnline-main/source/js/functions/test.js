import { allInit, fillInRemeText, kit, mdConverter,replaceSelection } from "../index.js"
replaceSelection(base64)