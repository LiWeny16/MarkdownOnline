// import { useState } from "react";
import "./App.less"
function App() {
  return (
    <>
      <div id="welcome">welcome React!</div>
    </>
  );
}

export default App;
